#include <memory>
#include <list>
#include <string>

struct RoutePoint
{
    float x;
    float y;
    float z;
};
